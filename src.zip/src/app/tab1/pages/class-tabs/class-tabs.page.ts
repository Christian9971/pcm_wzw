import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-class-tabs',
  templateUrl: './class-tabs.page.html',
  styleUrls: ['./class-tabs.page.scss'],
})
export class ClassTabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
