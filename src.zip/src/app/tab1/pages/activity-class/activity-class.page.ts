import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-class',
  templateUrl: './activity-class.page.html',
  styleUrls: ['./activity-class.page.scss'],
})
export class ActivityClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
