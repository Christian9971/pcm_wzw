import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tea-sign-result',
  templateUrl: './tea-sign-result.page.html',
  styleUrls: ['./tea-sign-result.page.scss'],
})
export class TeaSignResultPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
