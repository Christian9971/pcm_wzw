import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-class',
  templateUrl: './resource-class.page.html',
  styleUrls: ['./resource-class.page.scss'],
})
export class ResourceClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
