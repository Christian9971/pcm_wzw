import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-class',
  templateUrl: './setup-class.page.html',
  styleUrls: ['./setup-class.page.scss'],
})
export class SetupClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
