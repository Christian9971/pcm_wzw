export interface Course {
    id: number;
    name: string;
    teacher: string;
    sememster: any;
  }
