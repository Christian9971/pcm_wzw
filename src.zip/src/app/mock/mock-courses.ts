import { Course } from './../services/course';

export const COURSES: Course[] = [
    { id: 1, name: '软件工程', teacher: '黄一', sememster: '2019-2020-1' },
    { id: 2, name: '人工智能', teacher: '张三', sememster: '2019-2020-2' },
    { id: 3, name: '机器学习', teacher: '赵四', sememster: '2019-2020-1' },
    { id: 4, name: '大数据', teacher: '王五', sememster: '2019-2020-1' },
    { id: 5, name: '计算机网络', teacher: '李六', sememster: '2019-2020-1' },
  ];
